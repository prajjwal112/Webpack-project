const path = require('path');
module.exports={
    entry: './src/index.ts', // relative path
    module:{
        rules: [{
            test: /\.ts$/, // regEx if file is ending with .ts
            use: 'ts-loader', // apply ts-loader to ts file when above test passes
            include:[path.resolve(__dirname,'src')] // include ts files only that are in src folder
        }
        ]
    },
    output:{
        publicPath:'public',
        filename: 'bundle.js',
        path: path.resolve(__dirname, 'public') //creating absolute path __dirname finds the file(webpack.config.js) in our system and second parameter takes to 'public' from where we are
    }
}


/* Reads all the ts files from entry point and apply above specified rules if it passes 
   bundle all files into bundle.js in public folder
*/